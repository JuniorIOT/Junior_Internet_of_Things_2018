//pin definitions
const static int SS_pin = 8;                                                               // nss op de RFM95   (PB3 - pin 2)
const static int SCK_pin = 15;                                                              // SCK op de RFM95   (PB2 - pin 7)
const static int MOSI_pin = 16;                                                             // MOSI op de RFM95  (PB0 - pin 5)
//
